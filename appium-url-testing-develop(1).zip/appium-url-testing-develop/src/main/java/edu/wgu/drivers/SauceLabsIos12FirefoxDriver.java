package edu.wgu.drivers;

import edu.wgu.handlers.CrawlContext;
import edu.wgu.links.CleanURL;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SauceLabsIos12FirefoxDriver extends DeviceDriver {

    private int runId = 1;

    public SauceLabsIos12FirefoxDriver(List<String> urls,
            Consumer<CleanURL> callback, int batchId, boolean isReal, Consumer<CrawlContext> driverCallBack) {
        super(urls, callback, batchId, isReal, driverCallBack);
    }


    @Override
    protected DesiredCapabilities getCapabilities() {
        DesiredCapabilities caps = DesiredCapabilities.firefox();
        caps.setCapability("platform", "Windows 10");
        caps.setCapability("version", "66.0");
        caps.setCapability("maxDuration", 10000);
        return caps;
    }

    @Override
    protected WebDriver getDriver() {
        try {
            WebDriver driver = new RemoteWebDriver(new URL(getUrl()), getCapabilities());
            driver.manage().timeouts().implicitlyWait(200, TimeUnit.MICROSECONDS);
            driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
            return driver;
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return null;
    }

    protected String getDriverName() {
        return "iOS 12.2 Firefox";
    }
}
