package edu.wgu.drivers;

import lombok.Builder;
import lombok.Data;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Data
@Builder
public class ExecutionContext {
    private Path l1UrlsFilePath;
    private Path l2UrlsFilePath;
}
