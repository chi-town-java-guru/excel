package edu.wgu.handlers;

import edu.wgu.drivers.ExecutionContext;
import edu.wgu.indexer.Crawler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.stream.Collectors;
import org.openqa.selenium.WebDriver;

public class ContentCrawlerHandler implements DeviceDriverHandler{

    private Crawler crawler = new Crawler();

    @Override
    public void handle(WebDriver driver, ExecutionContext executionContext, CrawlContext context) {
        Map<String, String> cookies = context.getCookies().stream()
                .collect(Collectors.toMap(o -> o.getName(), o -> o.getValue()));
        crawler.startCrawl(context.getUrl(), 1, "C:\\Result\\index", cookies, executionContext.getL1UrlsFilePath(), executionContext.getL2UrlsFilePath());
    }

    private void writeLineToFile(String cleanUrlString, Path pathToWrite) {
        try {
            Files.write(pathToWrite, cleanUrlString.getBytes(),
                    StandardOpenOption.APPEND);
            Files.write(pathToWrite, "\r\n".getBytes(),
                    StandardOpenOption.APPEND);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
