package edu.wgu.handlers;

import edu.wgu.drivers.ExecutionContext;
import org.openqa.selenium.WebDriver;

public interface DeviceDriverHandler {

    void handle(WebDriver driver, ExecutionContext executionContext, CrawlContext context);

}
