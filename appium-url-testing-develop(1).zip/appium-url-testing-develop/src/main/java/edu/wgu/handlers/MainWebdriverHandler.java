package edu.wgu.handlers;

import edu.wgu.drivers.ExecutionContext;
import org.openqa.selenium.WebDriver;

public class MainWebdriverHandler implements DeviceDriverHandler {

    private ContentCrawlerHandler crawlHandler = new ContentCrawlerHandler();

    @Override
    public void handle(WebDriver driver, ExecutionContext executionContext, CrawlContext context) {
        crawlHandler.handle(driver, executionContext, context);
    }
}
